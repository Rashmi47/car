package com.mphasis.car.entities;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;


import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity(name="cabUser")
	public class User implements Serializable{

	
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int uid;
	@Column(nullable=false,length=25)
	private String uname;
	private String uemail;
	private String pass;
	private String role;
	@Column(nullable=false)
	private long phnum;
	private String gender;
	private String idproof;
	private int cusrating;
	private List<Long> emgcontact;
	@OneToMany(mappedBy="user",cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JsonIgnore
	private List<Route> route;
	@OneToMany(mappedBy="user",cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JsonIgnore
	private List<Booking> booking;
	@OneToMany(mappedBy="user",cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JsonIgnore
	private List<Payment> payment;
	public int getUid() {
	 return uid;
	}
	public void setUid(int uid) {
	 this.uid = uid;
	}
	public String getUname() {
	 return uname;
	}
	public void setUname(String uname) {
	 this.uname = uname;
	}
	public String getUemail() {
	 return uemail;
	}
	public void setUemail(String uemail) {
	 this.uemail = uemail;
	}
	public String getPass() {
	 return pass;
	}
	public void setPass(String pass) {
	 this.pass = pass;
	}
	public String getRole() {
	 return role;
	}
	public void setRole(String role) {
	 this.role = role;
	}
	public long getPhnum() {
	 return phnum;
	}
	public void setPhnum(long phnum) {
	 this.phnum = phnum;
	}
	public String getGender() {
	 return gender;
	}
	public void setGender(String gender) {
	 this.gender = gender;
	}
	public String getIdproof() {
	 return idproof;
	}
	public void setIdproof(String idproof) {
	 this.idproof = idproof;
	}
	public int getCusrating() {
	 return cusrating;
	}
	public void setCusrating(int cusrating) {
	 this.cusrating = cusrating;
	}
	public List<Long> getEmgcontact() {
	 return emgcontact;
	}
	public void setEmgcontact(List<Long> emgcontact) {
	 this.emgcontact = emgcontact;
	}
	
	public List<Booking> getBooking() {
	 return booking;
	}
	public void setBooking(List<Booking> booking) {
	 this.booking = booking;
	}
	public List<Route> getRoute() {
		return route;
	}
	public void setRoute(List<Route> route) {
		this.route = route;
	}
	public List<Payment> getPayment() {
		return payment;
	}
	public void setPayment(List<Payment> payment) {
		this.payment = payment;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	

	}



